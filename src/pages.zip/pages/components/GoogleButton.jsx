/**
 * GoogleButton — reusable Google OAuth button.
 * Redirects directly to the backend OAuth initiation route.
 * No token handling needed on the frontend — backend handles everything.
 */

const GoogleIcon = () => (
  <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
    <path
      d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844a4.14 4.14 0 0 1-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.875 2.684-6.615Z"
      fill="#4285F4"
    />
    <path
      d="M9 18c2.43 0 4.467-.806 5.956-2.184l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18Z"
      fill="#34A853"
    />
    <path
      d="M3.964 10.706A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.706V4.962H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.038l3.007-2.332Z"
      fill="#FBBC05"
    />
    <path
      d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.962L3.964 7.294C4.672 5.163 6.656 3.58 9 3.58Z"
      fill="#EA4335"
    />
  </svg>
);

export const GoogleButton = ({label = "Continue with Google", className}) => {
  const handleClick = () => {
    window.location.href = `${import.meta.env.VITE_BACKEND_URL}/api/auth/google`;
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      className={className}
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 10,
        width: "100%",
        padding: "11px 16px",
        background: "#fff",
        border: "1px solid rgba(0,0,0,0.12)",
        borderRadius: 10,
        fontSize: 14,
        fontWeight: 500,
        color: "#3c4043",
        cursor: "pointer",
        fontFamily: "inherit",
        transition: "all 0.18s",
        boxShadow: "0 1px 3px rgba(0,0,0,0.08)",
        letterSpacing: "-0.01em",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.boxShadow = "0 2px 8px rgba(0,0,0,0.14)";
        e.currentTarget.style.borderColor = "rgba(0,0,0,0.22)";
        e.currentTarget.style.transform = "translateY(-1px)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.boxShadow = "0 1px 3px rgba(0,0,0,0.08)";
        e.currentTarget.style.borderColor = "rgba(0,0,0,0.12)";
        e.currentTarget.style.transform = "translateY(0)";
      }}
    >
      <GoogleIcon />
      {label}
    </button>
  );
};

export default GoogleButton;
